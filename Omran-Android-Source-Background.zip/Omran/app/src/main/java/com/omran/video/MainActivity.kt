package com.omran.video

import android.Manifest
import android.app.Activity
import android.content.*
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.setPadding
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.util.UnstableApi
import java.io.File
import java.io.FileInputStream
import java.util.Locale
import kotlin.math.ceil

@UnstableApi
class MainActivity : AppCompatActivity() {
    private val bg = Color.rgb(9, 13, 22)
    private val card = Color.rgb(20, 26, 39)
    private val purple = Color.rgb(139, 77, 255)
    private val text = Color.rgb(245, 242, 255)
    private val muted = Color.rgb(170, 166, 184)

    private var videoUri: Uri? = null
    private var durationMs = 0L
    private var videoName = ""
    private var projectDir: File? = null
    private lateinit var root: LinearLayout
    private lateinit var info: TextView
    private lateinit var durationInput: EditText
    private lateinit var compression: Spinner
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private lateinit var saveButton: Button

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            videoUri = uri
            readVideo(uri)
        }
    }

    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                SplitterService.ACTION_UPDATE -> {
                    val current = intent.getIntExtra(SplitterService.EXTRA_CURRENT, 0)
                    val count = intent.getIntExtra(SplitterService.EXTRA_COUNT, 0)
                    progress.visibility = View.VISIBLE
                    progress.progress = if (count == 0) 0 else current * 100 / count
                    status.text = intent.getStringExtra(SplitterService.EXTRA_MESSAGE) ?: "جاري التقطيع..."
                    refreshProjectFiles()
                }
                SplitterService.ACTION_DONE -> {
                    progress.progress = 100
                    status.text = intent.getStringExtra(SplitterService.EXTRA_MESSAGE) ?: "تم التقطيع بنجاح"
                    refreshProjectFiles()
                    toast("اكتمل التقطيع ويمكنك الآن اختيار المقاطع وحفظها")
                }
                SplitterService.ACTION_ERROR -> {
                    status.text = intent.getStringExtra(SplitterService.EXTRA_MESSAGE) ?: "حدث خطأ"
                    refreshProjectFiles()
                }
            }
        }
    }

    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { treeUri ->
        if (treeUri != null) exportSelectedToFolder(treeUri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        ContextCompat.registerReceiver(this, receiver, IntentFilter().apply {
            addAction(SplitterService.ACTION_UPDATE); addAction(SplitterService.ACTION_DONE); addAction(SplitterService.ACTION_ERROR)
        }, ContextCompat.RECEIVER_NOT_EXPORTED)
        if (android.os.Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        refreshProjectFiles()
    }

    override fun onResume() { super.onResume(); refreshProjectFiles() }
    override fun onDestroy() { unregisterReceiver(receiver); super.onDestroy() }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(22); layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(tv("عمران", 32f, text, true).apply { gravity = Gravity.CENTER; setPadding(0, 28, 0, 4) }, lp(-1,-2))
        root.addView(tv("تقطيع الفيديو بدون إنترنت", 16f, muted, false).apply { gravity = Gravity.CENTER; setPadding(0,0,0,24) }, lp(-1,-2))

        root.addView(button("📁  اختيار فيديو", purple).apply { setOnClickListener { picker.launch(arrayOf("video/*")) } }, lp(-1,62,0,0,0,18))
        info = tv("لم يتم اختيار فيديو بعد", 15f, muted, false).apply { setPadding(16); setBackgroundColor(card) }
        root.addView(info, lp(-1,-2,0,0,0,18))

        root.addView(section("إعدادات التقطيع"), lp(-1,-2,0,0,0,10))
        root.addView(tv("مدة كل مقطع (ساعة:دقيقة:ثانية)", 15f, text, true), lp(-1,-2,0,0,0,6))
        durationInput = EditText(this).apply {
            setText("00:01:00"); hint = "00:01:00"; textSize = 18f; setTextColor(text); setHintTextColor(muted)
            setSingleLine(true); gravity = Gravity.CENTER; setPadding(14); setBackgroundColor(card); inputType = android.text.InputType.TYPE_CLASS_TEXT
        }
        root.addView(durationInput, lp(-1,58,0,0,0,18))

        root.addView(tv("تقليل حجم الفيديو والميجابايت", 15f, text, true), lp(-1,-2,0,0,0,6))
        compression = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                arrayOf("الحجم الأصلي — أعلى جودة", "متوسط — حجم أقل", "منخفض — حجم أصغر بكثير"))
        }
        root.addView(compression, lp(-1,58,0,0,0,20))

        root.addView(button("⚡  ابدأ التقطيع في الخلفية", purple).apply { setOnClickListener { startSplitting() } }, lp(-1,62,0,0,0,14))
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max=100; visibility=View.GONE }
        root.addView(progress, lp(-1,10,0,0,0,10))
        status = tv("",14f,muted,false).apply { gravity=Gravity.CENTER; setPadding(0,10) }
        root.addView(status, lp(-1,-2))

        saveButton = button("💾  اختيار المقاطع وحفظها", Color.rgb(44,51,68)).apply { setOnClickListener { chooseClipsToSave() } }
        root.addView(saveButton, lp(-1,58,0,0,0,14))
        root.addView(tv("التقطيع يستمر أثناء استخدام تطبيقات أخرى. سيظهر إشعار يوضح التقدم. لكل فيديو مجلد مشروع مستقل.",13f,muted,false).apply { gravity=Gravity.CENTER; setPadding(12) }, lp(-1,-2))
    }

    private fun readVideo(uri: Uri) {
        try {
            val r=MediaMetadataRetriever(); r.setDataSource(this,uri)
            durationMs=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            r.release(); videoName=queryName(uri)
            val count=if(durationMs>0 && parseTime(durationInput.text.toString())>0) ceil(durationMs.toDouble()/parseTime(durationInput.text.toString())).toInt() else 0
            info.text="الفيديو: $videoName\nالمدة: ${format(durationMs)}${if(count>0) "\nعدد المقاطع المتوقع: $count" else ""}\n\nسيتم إنشاء مجلد خاص بهذا الفيديو تلقائيًا."
        } catch(e:Exception){ info.text="تعذر قراءة الفيديو: ${e.message}" }
    }

    private fun startSplitting() {
        val uri=videoUri ?: return toast("اختر فيديو أولًا")
        val segment=parseTime(durationInput.text.toString())
        if(segment<=0) return toast("اكتب مدة صحيحة مثل 00:01:00")
        if(durationMs<=0) return toast("تعذر معرفة مدة الفيديو")
        val count=ceil(durationMs.toDouble()/segment).toInt()
        progress.visibility=View.VISIBLE; progress.progress=0; status.text="سيبدأ التقطيع في الخلفية — $count مقطع"
        val intent=Intent(this, SplitterService::class.java).apply {
            action=SplitterService.ACTION_START
            putExtra(SplitterService.EXTRA_URI,uri.toString())
            putExtra(SplitterService.EXTRA_SEGMENT_MS,segment)
            putExtra(SplitterService.EXTRA_VIDEO_NAME,videoName)
            putExtra(SplitterService.EXTRA_COMPRESSION,compression.selectedItemPosition)
        }
        ContextCompat.startForegroundService(this,intent)
    }

    private fun refreshProjectFiles() {
        val path=getSharedPreferences("omran",MODE_PRIVATE).getString("latest_project",null) ?: return
        val dir=File(path); if(dir.exists()){ projectDir=dir; saveButton.text="💾  اختيار المقاطع وحفظها (${dir.listFiles()?.count { it.extension.equals("mp4",true) } ?: 0})" }
    }

    private fun chooseClipsToSave() {
        refreshProjectFiles(); val files=projectDir?.listFiles { f -> f.isFile && f.extension.equals("mp4",true) }?.sortedBy { it.name } ?: emptyList()
        if(files.isEmpty()) return toast("لا توجد مقاطع محفوظة بعد")
        val names=files.map { it.name }.toTypedArray(); val checked=BooleanArray(files.size)
        AlertDialog.Builder(this).setTitle("اختر المقاطع التي تريد حفظها")
            .setMultiChoiceItems(names,checked){ _,which,isChecked -> checked[which]=isChecked }
            .setNegativeButton("إلغاء",null)
            .setPositiveButton("اختيار مكان الحفظ"){ _,_ ->
                val selected=files.filterIndexed { i,_ -> checked[i] }
                if(selected.isEmpty()) toast("اختر مقطعًا واحدًا على الأقل") else {
                    selectedFilesForExport=selected
                    folderPicker.launch(null)
                }
            }.show()
    }

    private var selectedFilesForExport: List<File> = emptyList()
    private fun exportSelectedToFolder(treeUri: Uri) {
        try { contentResolver.takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        Thread {
            try {
                val tree=DocumentFile.fromTreeUri(this,treeUri) ?: throw Exception("تعذر فتح المجلد")
                selectedFilesForExport.forEach { file ->
                    val target=tree.createFile("video/mp4",file.name) ?: throw Exception("تعذر إنشاء ${file.name}")
                    contentResolver.openOutputStream(target.uri)?.use { out -> FileInputStream(file).use { it.copyTo(out) } }
                }
                runOnUiThread { toast("تم حفظ ${selectedFilesForExport.size} مقطع على الهاتف") }
            } catch(e:Exception){ runOnUiThread { toast("تعذر الحفظ: ${e.message}") } }
        }.start()
    }

    private fun parseTime(s:String):Long {
        val p=s.trim().split(":").mapNotNull{it.toLongOrNull()}; if(p.size!=3)return 0
        val h=p[0].coerceAtLeast(0); val m=p[1].coerceIn(0,59); val sec=p[2].coerceIn(0,59)
        return (h*3600+m*60+sec)*1000
    }
    private fun format(ms:Long):String { val sec=ms/1000; return String.format(Locale.US,"%02d:%02d:%02d",sec/3600,(sec%3600)/60,sec%60) }
    private fun queryName(uri:Uri):String=contentResolver.query(uri,arrayOf("_display_name"),null,null,null)?.use{if(it.moveToFirst())it.getString(0)else"video.mp4"}?:"video.mp4"
    private fun tv(s:String,size:Float,c:Int,bold:Boolean)=TextView(this).apply{text=s;textSize=size;setTextColor(c);if(bold)setTypeface(typeface,android.graphics.Typeface.BOLD)}
    private fun button(s:String,c:Int)=Button(this).apply{text=s;textSize=16f;setTextColor(Color.WHITE);setBackgroundColor(c);isAllCaps=false;minHeight=0}
    private fun section(s:String)=tv(s,20f,text,true).apply{setPadding(4,8,4,8)}
    private fun lp(w:Int,h:Int,l:Int=0,t:Int=0,r:Int=0,b:Int=0)=LinearLayout.LayoutParams(w,h).apply{setMargins(l,t,r,b)}
    private fun toast(s:String)=runOnUiThread{Toast.makeText(this,s,Toast.LENGTH_LONG).show()}
}
