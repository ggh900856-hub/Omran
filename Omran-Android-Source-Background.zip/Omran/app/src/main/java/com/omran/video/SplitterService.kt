package com.omran.video

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.*
import java.io.File
import java.util.Locale
import java.util.concurrent.CountDownLatch
import kotlin.math.ceil

@UnstableApi
class SplitterService : Service() {
    companion object {
        const val ACTION_START = "com.omran.video.START_SPLIT"
        const val ACTION_UPDATE = "com.omran.video.SPLIT_UPDATE"
        const val ACTION_DONE = "com.omran.video.SPLIT_DONE"
        const val ACTION_ERROR = "com.omran.video.SPLIT_ERROR"
        const val EXTRA_URI = "uri"
        const val EXTRA_SEGMENT_MS = "segment_ms"
        const val EXTRA_VIDEO_NAME = "video_name"
        const val EXTRA_COMPRESSION = "compression"
        const val EXTRA_COUNT = "count"
        const val EXTRA_CURRENT = "current"
        const val EXTRA_MESSAGE = "message"
        private const val CHANNEL_ID = "omran_splitter"
        private const val NOTIFICATION_ID = 501
    }

    private var cancelled = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != ACTION_START) return START_REDELIVER_INTENT
        cancelled = false
        if (Build.VERSION.SDK_INT >= 35) {
            startForeground(NOTIFICATION_ID, notification("جاري تجهيز التقطيع...", 0, false), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING)
        } else {
            startForeground(NOTIFICATION_ID, notification("جاري تجهيز التقطيع...", 0, false))
        }
        Thread { split(intent) }.start()
        return START_REDELIVER_INTENT
    }

    private fun split(intent: Intent) {
        try {
            val uri = Uri.parse(intent.getStringExtra(EXTRA_URI) ?: error("لم يتم تحديد الفيديو"))
            val segment = intent.getLongExtra(EXTRA_SEGMENT_MS, 0L)
            val name = intent.getStringExtra(EXTRA_VIDEO_NAME) ?: "فيديو.mp4"
            val compression = intent.getIntExtra(EXTRA_COMPRESSION, 0)
            val duration = duration(uri)
            require(segment > 0 && duration > 0) { "بيانات الفيديو أو مدة المقطع غير صحيحة" }
            val count = ceil(duration.toDouble() / segment).toInt()
            val safeName = name.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9_\u0600-\u06FF -]"), "_").take(80)
            val project = File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "عمران/$safeName").apply { mkdirs() }
            getSharedPreferences("omran", MODE_PRIVATE).edit().putString("latest_project", project.absolutePath).apply()

            for (i in 0 until count) {
                if (cancelled) throw InterruptedException("تم إلغاء التقطيع")
                val start = i * segment
                val end = minOf(duration, start + segment)
                val out = File(project, String.format(Locale.US, "مقطع_%03d_%s.mp4", i + 1, formatFileTime(start)))
                if (out.exists() && out.length() > 0) {
                    sendUpdate(i + 1, count, "تم استكمال المقطع ${i + 1} من $count")
                    continue
                }
                sendUpdate(i, count, "جاري تقطيع المقطع ${i + 1} من $count")
                exportSegment(uri, start, end, out, compression)
                sendUpdate(i + 1, count, "تم ${i + 1} من $count")
            }
            val done = Intent(ACTION_DONE).setPackage(packageName).putExtra(EXTRA_COUNT, count).putExtra(EXTRA_MESSAGE, "تم التقطيع بنجاح: $count مقطع")
            sendBroadcast(done)
            val nm = getSystemService(NotificationManager::class.java)
            nm.notify(NOTIFICATION_ID, notification("اكتمل التقطيع — $count مقطع", 100, true))
            stopForeground(false)
            stopSelf()
        } catch (e: Exception) {
            val msg = if (e is InterruptedException) "تم إلغاء التقطيع" else (e.message ?: "حدث خطأ أثناء التقطيع")
            sendBroadcast(Intent(ACTION_ERROR).setPackage(packageName).putExtra(EXTRA_MESSAGE, msg))
            val nm = getSystemService(NotificationManager::class.java)
            nm.notify(NOTIFICATION_ID, notification(msg, 0, true))
            stopForeground(false)
            stopSelf()
        }
    }

    private fun sendUpdate(current: Int, count: Int, message: String) {
        val percent = if (count == 0) 0 else current * 100 / count
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification("$message — $percent%", percent, false))
        sendBroadcast(Intent(ACTION_UPDATE).setPackage(packageName).putExtra(EXTRA_CURRENT, current).putExtra(EXTRA_COUNT, count).putExtra(EXTRA_MESSAGE, message))
    }

    private fun exportSegment(uri: Uri, start: Long, end: Long, out: File, compression: Int) {
        val clip = MediaItem.Builder().setUri(uri).setClippingConfiguration(
            MediaItem.ClippingConfiguration.Builder().setStartPositionMs(start).setEndPositionMs(end).build()
        ).build()
        val edited = EditedMediaItem.Builder(clip).build()
        val builder = Transformer.Builder(this).setVideoMimeType(MimeTypes.VIDEO_H264).setAudioMimeType(MimeTypes.AUDIO_AAC)
        if (compression > 0) {
            val base = MediaMetadataRetriever().let { r ->
                r.setDataSource(this, uri)
                val b = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toLongOrNull() ?: 4_000_000L
                r.release(); b
            }
            val bitrate = if (compression == 1) (base * 0.55).toInt().coerceIn(500_000, 8_000_000) else (base * 0.30).toInt().coerceIn(300_000, 4_000_000)
            builder.setEncoderFactory(DefaultEncoderFactory.Builder(this)
                .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(bitrate).build())
                .setRequestedAudioEncoderSettings(AudioEncoderSettings.Builder().setBitrate(if (compression == 1) 96_000 else 64_000).build())
                .build())
        }
        val latch = CountDownLatch(1)
        var failure: Throwable? = null
        val transformer = builder.addListener(object : Transformer.Listener {
            override fun onCompleted(composition: Composition, result: ExportResult) { latch.countDown() }
            override fun onError(composition: Composition, result: ExportResult, exception: ExportException) { failure = exception; latch.countDown() }
        }).build()
        android.os.Handler(mainLooper).post { transformer.start(edited, out.absolutePath) }
        latch.await()
        failure?.let { throw RuntimeException(it) }
    }

    private fun duration(uri: Uri): Long {
        val r = MediaMetadataRetriever(); r.setDataSource(this, uri)
        val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        r.release(); return d
    }

    private fun notification(text: String, progress: Int, done: Boolean): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_slideshow)
            .setContentTitle("عمران — تقطيع الفيديو")
            .setContentText(text)
            .setOngoing(!done)
            .setOnlyAlertOnce(true)
            .setProgress(100, progress.coerceIn(0, 100), false)
            .build()

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "تقطيع الفيديو", NotificationManager.IMPORTANCE_LOW).apply { description = "إشعارات تقدم تقطيع الفيديو في عمران" }
            )
        }
    }

    private fun formatFileTime(ms: Long): String = String.format(Locale.US, "%02d-%02d-%02d", (ms / 3_600_000), (ms / 60_000) % 60, (ms / 1000) % 60)
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { cancelled = true; super.onDestroy() }
}
